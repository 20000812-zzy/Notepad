package com.example.notepad;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class UserActivity extends AppCompatActivity {
    private EditText nameEdit;
    private EditText ageEdit;
    private EditText marriedEdit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_userinfo);
        SharedPreferences.Editor editor = getSharedPreferences("data", MODE_PRIVATE).edit();
        editor.putString("name", "ZhouYang");
        editor.putString("age", "27");
        editor.putBoolean("married", false);
        editor.apply();
        SharedPreferences pref = getSharedPreferences("data", MODE_PRIVATE);
        nameEdit = (EditText) findViewById(R.id.name);
        ageEdit = (EditText) findViewById(R.id.age);
        marriedEdit = (EditText) findViewById(R.id.married);
        //将姓名、年龄、婚姻状况都设置到文本框中
        String name = pref.getString("name", "XiaoMing");
        String age = pref.getString("age", "20");
        Boolean married = pref.getBoolean("married", false);
        String str2 = Boolean.toString(married);
        nameEdit.setText(name);
        ageEdit.setText(age);
        marriedEdit.setText(str2);
    }
}
